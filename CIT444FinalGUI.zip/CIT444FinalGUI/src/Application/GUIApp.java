package Application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class GUIApp extends Application {

    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe"; 
    private static final String DB_USER = "system";
    private static final String DB_PASSWORD = "jm64108034";

    private ObservableList<Hotel> hotelData = FXCollections.observableArrayList();
    private ObservableList<String> cityData = FXCollections.observableArrayList();
    private Map<Integer, HotelRatings> ratingsData = new HashMap<>();

    private Label loadingLabel;
    private ComboBox<String> cityComboBox;
    private TextField searchTextField;
    private ListView<String> hotelListView;  
    private Label hotelTitleLabel;
    private Label hotelRatingsLabel;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Hotel Ratings");

        loadingLabel = new Label("Loading data...");

        VBox loadingVBox = new VBox(10, loadingLabel);
        Scene loadingScene = new Scene(loadingVBox, 400, 200);

        primaryStage.setScene(loadingScene);
        primaryStage.show();

        loadDataInBackground(primaryStage);
    }

    private void loadDataInBackground(Stage primaryStage) {

        Task<Void> loadDataTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                // Load hotel data
                loadHotelData();

                // Load city data
                loadCityData();

                // Load ratings data
                loadRatingsData();

                return null;
            }

            @Override
            protected void succeeded() {
                super.succeeded();
                initializeGUI(primaryStage);
            }

            @Override
            protected void failed() {
                super.failed();
                System.err.println("Data loading failed.");
            }
        };

        new Thread(loadDataTask).start();
    }

    private void loadHotelData() {
        String sql = "SELECT HOTELID, NAME, CITY, COUNTRY FROM HOTEL";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            int totalRows = getTotalRowCount("HOTEL"); 
            int currentRow = 0;

            while (rs.next()) {
                int hotelId = rs.getInt("HOTELID");
                String hotelName = rs.getString("NAME");
                String city = rs.getString("CITY");
                String country = rs.getString("COUNTRY");

                Hotel hotel = new Hotel(hotelId, hotelName, city, country);
                hotelData.add(hotel);

                currentRow++;
                System.out.println("Processed hotel " + currentRow + " of " + totalRows + " (" + (currentRow * 100 / totalRows) + "% complete)");

            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error loading hotel data: " + e.getMessage(), e);
        }
    }

    private int getTotalRowCount(String tableName) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + tableName;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private void loadRatingsData() {
        String sql = "SELECT HOTELID, AVERAGE_CLEANLINESSSCORE, AVERAGE_PRICESCORE, " +
                     "AVERAGE_SERVICESCORE, AVERAGE_LOCATIONSCORE FROM RATINGSAVERAGE";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            int totalRatings = getTotalRowCount("RATINGSAVERAGE"); 
            int currentRating = 0;

            System.out.println("Loading ratings data...");

            if (!rs.isBeforeFirst()) {
                System.out.println("No ratings data found.");
            }

            while (rs.next()) {
                int hotelId = rs.getInt("HOTELID");

                int cleanlinessScore = rs.getInt("AVERAGE_CLEANLINESSSCORE");
                int priceScore = rs.getInt("AVERAGE_PRICESCORE");
                int serviceScore = rs.getInt("AVERAGE_SERVICESCORE");
                int locationScore = rs.getInt("AVERAGE_LOCATIONSCORE");

                double overallScore = (cleanlinessScore + priceScore + serviceScore + locationScore) / 4.0;

                HotelRatings ratings = new HotelRatings(hotelId, cleanlinessScore, priceScore, serviceScore, locationScore, overallScore);
                ratingsData.put(hotelId, ratings);

                currentRating++;
                System.out.println("Processed rating " + currentRating + " of " + totalRatings + " (" + (currentRating * 100 / totalRatings) + "% complete)");
            }

        } catch (SQLException e) {
            System.err.println("Error loading ratings data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadCityData() {
        String sql = "SELECT DISTINCT CITY FROM HOTEL";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                cityData.add(rs.getString("CITY"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void initializeGUI(Stage primaryStage) {

        cityComboBox = new ComboBox<>(cityData);
        cityComboBox.setPromptText("Select city...");
        
        // Listener for combo box selection to filter hotels by city
        cityComboBox.setOnAction(event -> filterHotels(searchTextField.getText(), cityComboBox.getValue()));  

        // Initialize the search TextField
        searchTextField = new TextField();
        searchTextField.setPromptText("Search for hotels...");
        searchTextField.textProperty().addListener((observable, oldValue, newValue) -> filterHotels(newValue, cityComboBox.getValue()));  

        // ListView for displaying hotels
        hotelListView = new ListView<>();
        ObservableList<String> hotelNames = FXCollections.observableArrayList();
        for (Hotel hotel : hotelData) {
            hotelNames.add(hotel.getName());
        }
        hotelListView.setItems(hotelNames);

        hotelTitleLabel = new Label("Select a hotel to see its ratings");
        hotelTitleLabel.setFont(Font.font("Arial", 20));
        hotelTitleLabel.setStyle("-fx-font-weight: bold; -fx-alignment: center;"); 

        hotelRatingsLabel = new Label(""); 
        hotelRatingsLabel.setFont(Font.font("Arial", 14)); 
        hotelRatingsLabel.setStyle("-fx-alignment: center;");


        hotelListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                displayHotelRatings(newValue); 
            }
        });

        VBox vbox = new VBox(10, cityComboBox, searchTextField, hotelListView, hotelTitleLabel, hotelRatingsLabel);
        vbox.setStyle("-fx-alignment: center;"); 
        Scene mainScene = new Scene(vbox, 800, 600);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    private void filterHotels(String searchTerm, String selectedCity) {
        ObservableList<String> filteredHotels = FXCollections.observableArrayList();
        for (Hotel hotel : hotelData) {
            boolean matchesSearch = hotel.getName().toLowerCase().contains(searchTerm.toLowerCase());
            boolean matchesCity = selectedCity == null || hotel.getCity().equals(selectedCity);


            if (matchesSearch && matchesCity) {
                filteredHotels.add(hotel.getName());
            }
        }
        hotelListView.setItems(filteredHotels);
    }

    private void displayHotelRatings(String hotelName) {
        Hotel selectedHotel = null;
        for (Hotel hotel : hotelData) {
            if (hotel.getName().equals(hotelName)) {
                selectedHotel = hotel;
                break;
            }
        }


        if (selectedHotel != null) {
            HotelRatings ratings = ratingsData.get(selectedHotel.getHotelId());
            if (ratings != null) {
                hotelTitleLabel.setText("Ratings for " + selectedHotel.getName()); 
                hotelRatingsLabel.setText("Cleanliness: " + ratings.getCleanlinessScore() + "\n" +
                        "Price: " + ratings.getPriceScore() + "\n" +
                        "Service: " + ratings.getServiceScore() + "\n" +
                        "Location: " + ratings.getLocationScore() + "\n" +
                        "Overall: " + ratings.getOverallScore());
            } else {
                hotelTitleLabel.setText("No ratings available for this hotel."); 
                hotelRatingsLabel.setText("");
            }
        }
    }

    public static class Hotel {
        private int hotelId;
        private String name;
        private String city;
        private String country;

        public Hotel(int hotelId, String name, String city, String country) {
            this.hotelId = hotelId;
            this.name = name;
            this.city = city;
            this.country = country;
        }

        public int getHotelId() {
            return hotelId;
        }

        public String getName() {
            return name;
        }

        public String getCity() {
            return city;
        }

        public String getCountry() {
            return country;
        }
    }

    public static class HotelRatings {
        private int hotelId;
        private int cleanlinessScore;
        private int priceScore;
        private int serviceScore;
        private int locationScore;
        private double overallScore;

        public HotelRatings(int hotelId, int cleanlinessScore, int priceScore, int serviceScore, int locationScore, double overallScore) {
            this.hotelId = hotelId;
            this.cleanlinessScore = cleanlinessScore;
            this.priceScore = priceScore;
            this.serviceScore = serviceScore;
            this.locationScore = locationScore;
            this.overallScore = overallScore;
        }

        public int getCleanlinessScore() {
            return cleanlinessScore;
        }

        public int getPriceScore() {
            return priceScore;
        }

        public int getServiceScore() {
            return serviceScore;
        }

        public int getLocationScore() {
            return locationScore;
        }

        public double getOverallScore() {
            return overallScore;
        }
    }
}
